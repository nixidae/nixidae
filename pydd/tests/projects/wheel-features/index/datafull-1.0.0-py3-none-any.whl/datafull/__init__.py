GREETING = 'hello'

def main():
    print(GREETING)
