"""A PEP 517 backend whose only build requirement arrives through the hook."""

import base64
import hashlib
import tomllib
import zipfile
from pathlib import Path


def get_requires_for_build_wheel(config_settings=None):
    return ["hookprobe-extra"]


def get_requires_for_build_sdist(config_settings=None):
    return []


def _hash(data):
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    import hookprobe_extra

    project = tomllib.loads(Path("pyproject.toml").read_text())["project"]
    name, version = project["name"].replace("-", "_"), project["version"]
    dist_info = f"{name}-{version}.dist-info"
    files = {
        f"{name}.py": f"HOOK = {hookprobe_extra.SAID!r}\n".encode(),
        f"{dist_info}/METADATA": f"Metadata-Version: 2.1\nName: {project['name']}\nVersion: {version}\n".encode(),
        f"{dist_info}/WHEEL": b"Wheel-Version: 1.0\nRoot-Is-Purelib: true\nTag: py3-none-any\n",
    }
    record = [f"{path},{_hash(data)},{len(data)}" for path, data in sorted(files.items())]
    files[f"{dist_info}/RECORD"] = ("\n".join([*record, f"{dist_info}/RECORD,,"]) + "\n").encode()
    filename = f"{name}-{version}-py3-none-any.whl"
    with zipfile.ZipFile(Path(wheel_directory) / filename, "w") as wheel:
        for path, data in sorted(files.items()):
            info = zipfile.ZipInfo(path, (2020, 1, 1, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            wheel.writestr(info, data)
    return filename
