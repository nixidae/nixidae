PLATFORM = 'musllinux_1_2'
